"""
Workshop 3 framework v1.1
By Jack Seymour

# Follow allong with the written workshop instructions and
    use this application stub to impliment the functionality.

# Locations marked with TODO: are places that need implimentation.

# The pass command in a stub is used to end a block and continue execution.
    This is used to define portsion of code structure that are awaiting implimentation.
    You should remove pass when you impliment the functionality.
"""

# TODO: import package functions:
# EXAMPLE FORMAT: from package.file imprort function_name, (...)

# Global (Application) variable definitions
database = {
    # TODO: Default users dictionary
}
donations = []
authorized_user = ""

# Main application loop
while True:
    # TODO: Show homepage

    # TODO: Get user action then process user input
    pass
