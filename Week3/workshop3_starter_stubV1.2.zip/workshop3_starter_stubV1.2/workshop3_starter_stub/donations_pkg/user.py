"""
User functions
"""


def login(database, username, password):
    """
    login
        # TODO: Login action
    """


def register(database, username, password):
    """
    register
        # TODO: Register user action
    """
