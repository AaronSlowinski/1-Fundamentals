"""
Homepage functions
"""


def show_homepage(authorized_user):
    """
    show_homepage
        # TODO: Homepage menu view
    """


def donate(username):
    """
    donate
        # TODO: Donation action
    """


def show_donations(donations):
    """
    show_definition
        # TODO: show donations view
    """
